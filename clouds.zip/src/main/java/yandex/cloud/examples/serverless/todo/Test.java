package yandex.cloud.examples.serverless.todo;

import org.json.JSONObject;
import yandex.cloud.examples.serverless.todo.utils.MyStaticContext;
import yandex.cloud.examples.serverless.todo.utils.TrackBrowser;

import javax.script.ScriptException;
import java.io.IOException;

public class Test {

    private static final MyStaticContext staticContext = MyStaticContext.getInstance();

    public static void main(String[] args) throws NoSuchMethodException, ScriptException, IOException {

    }

}
